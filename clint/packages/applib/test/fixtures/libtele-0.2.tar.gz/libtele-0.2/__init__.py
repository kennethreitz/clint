"""
This module contains the methods to query http://tele.at.

All methods expects you to use ``unicode``-Strings and local aware
``datetime.datetime``\s! Since this module depends on the ``pytz``-Module
you can use it without adding a dependency to your application.
"""

__version__ = "0.2"
__license__ = "GPLv3"

